package com.certification.Utili;

import java.io.IOException;
import java.lang.reflect.Method;
import org.apache.log4j.xml.DOMConfigurator;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;



public class BrowserMethods extends WebAppCommon
{
	
	@BeforeTest
	public void createHtmltView() throws IOException  
	{
		report=new ExtentReports(PropertyHandler.getProperty("AutomationHTMLView"),true);
	}
	@BeforeClass
	public void openBrowser() throws Exception
	{
		//report=new ExtentReports(PropertyHandler.getProperty("AutomationHTMLView"),true); 
	}
	@BeforeMethod
	public void loadLocater() throws IOException
	{
		DOMConfigurator.configure(PropertyHandler.getProperty("Loger"));
	}
	@AfterClass
	public void closeBrowser() throws Exception
	{
		
	}

	@AfterMethod
	public void postTestCaseExecution(ITestResult result ,Method method) throws Exception
	{
		Test test = method.getAnnotation(Test.class);
		String testCaseID = test.testName();
		String status = Integer.toString(result.getStatus());
		JiraRestUtility.updateTestStatusInJira(result, method);	
		try{
			if(result.getStatus()==ITestResult.FAILURE)
			{
				LogerData.fail(result.getMethod().getMethodName());
			}else if(result.getStatus()==ITestResult.SUCCESS)
			{
				LogerData.pass(result.getMethod().getMethodName());
			}
			else if(result.getStatus() == ITestResult.SKIP)
			{
				LogerData.skip(result.getMethod().getMethodName(), result.getMethod().getMethodName());
			}
		}
		catch(Exception e)
		{
		}
		report.flush();
	}

}



