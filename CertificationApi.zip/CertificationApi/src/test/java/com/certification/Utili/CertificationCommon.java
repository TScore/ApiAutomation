package com.certification.Utili;

import java.awt.AWTException;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CertificationCommon extends BrowserMethods
{
	
	public String   loginCertification(String UserName,String Password) throws IOException, JSONException, AWTException
	{
		
		client = new OkHttpClient();
		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType, "{\"username\": \""+UserName+"\", \"password\": \""+Password+"\"}");
		request = new Request.Builder()
				.url(url+"/partner-user/authenticate")
				.post(body)
				.addHeader("content-type", "application/json")
				.addHeader("url", url)
				//.addHeader("cache-control", "no-cache")
				//.addHeader("postman-token", "412daf2d-928a-9160-d88e-449e5bb8a4ee")
				.build();
		Response response = client.newCall(request).execute();
		int responseCode=response.code();
		String TokenCreate = null ;	
		if(responseCode==200)
			{
				String jsonData = response.body().string();
				JSONObject jsonObject = new JSONObject(jsonData);
				JSONObject chapitresJsonObject = jsonObject.getJSONObject("user");
				String firstname=chapitresJsonObject.getString("firstname");
				LogerData.info("Certification firstname is::"+firstname);
				Assert.assertEquals(UserName, firstname);
				String lastname=chapitresJsonObject.getString("lastname");
				LogerData.info("Certification firstname is::"+lastname);
				TokenCreate=chapitresJsonObject.getString("token");
				LogerData.info("TokenCreate::"+TokenCreate);
				LogerData.info("Login in certification is working.");
				
			}else if(responseCode==400)
			{
				LogerData.fail("504 Bad Gateway");
				
			}else if(responseCode==504)
			{
				LogerData.fail("Not able to authenticate user::::504 Gateway TimeOut Error");
			}
		return TokenCreate;
	}
}
