package com.certification.automationScript.certificationSearch;

import java.awt.AWTException;
import java.io.IOException;

import org.json.JSONException;
import org.testng.annotations.Test;

import com.certification.Utili.CertificationCommon;
import com.certification.Utili.LogerData;
import com.certification.Utili.PropertyHandler;
import com.certification.page.certificationSearch.CertificationSearchDetailUtili;

public class CertificationSearchDetailScript extends CertificationSearchDetailUtili
{
	//CertificationCommon certificationCommon=new CertificationCommon();
	String UserName=PropertyHandler.getProperty("USERNAME");
	String Password=PropertyHandler.getProperty("PASSWORD");
	
	
	@Test(enabled =true,dataProviderClass=com.certification.excelReader.ExcelTestDataProvider.class, dataProvider="ExcelDataProvider",priority=1)
	public void CertificationSearch_IDTest(String  searchUseingFilter,String api) throws IOException, JSONException, AWTException
	{
		//String SearchUseingFilter = String.valueOf(searchUseingFilter);
		searchUseingFilter=searchUseingFilter.replace("_","");
		logger=report.startTest("Certification search::Certification Search Useing ID");
		LogerData.startTestCase("Certification search::Certification Search Useing ID");
		String token=loginCertification(UserName,Password);
		getCertificationSearch(searchUseingFilter,api,token,"MODULE_ID");
	}

	@Test(enabled =true,dataProviderClass=com.certification.excelReader.ExcelTestDataProvider.class, dataProvider="ExcelDataProvider",priority=2)
	public void CertificationSearch_TitleTest(String searchUseingFilter,String api) throws IOException, JSONException, AWTException
	{
		logger=report.startTest("Certification search::Certification Search useing Title Test");
		LogerData.startTestCase("Certification search::Certification Search useing Title Test");
		String token=loginCertification(UserName,Password);
		getCertificationSearch(searchUseingFilter,api,token,"TITLE");

	}

	@Test(enabled =true,dataProviderClass=com.certification.excelReader.ExcelTestDataProvider.class, dataProvider="ExcelDataProvider",priority=3)
	public void CertificationSearch_DescriptionTest(String searchUseingFilter,String api) throws IOException, JSONException, AWTException
	{
		logger=report.startTest("Certification search::Certification Search Description Test");
		LogerData.startTestCase("Certification search::Certification Search Description Test");
		String token=loginCertification(UserName,Password);
		getCertificationSearch(searchUseingFilter,api,token,"DESCRIPTION");
	}
}
