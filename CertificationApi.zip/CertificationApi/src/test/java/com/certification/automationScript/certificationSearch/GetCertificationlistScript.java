package com.certification.automationScript.certificationSearch;

import java.awt.AWTException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

import com.certification.Utili.LogerData;
import com.certification.Utili.PropertyHandler;
import com.certification.page.certificationSearch.GetCertificationlistScriptUtili;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GetCertificationlistScript extends GetCertificationlistScriptUtili  {
	String UserName=PropertyHandler.getProperty("USERNAME");
	String Password=PropertyHandler.getProperty("PASSWORD");
	
	
	@Test(enabled =true,dataProviderClass=com.certification.excelReader.ExcelTestDataProvider.class, dataProvider="ExcelDataProvider",priority=1)
	public void LoginCertificationManagerTest(String api) throws IOException, JSONException, AWTException, InvalidFormatException
	{
		logger=report.startTest("Get certification list::Login Certification Manager Test");
		LogerData.startTestCase("Get certification list::Login Certification Manager Test");
		logIn(UserName,Password,api);
	}

	@Test(enabled =true,dataProviderClass=com.certification.excelReader.ExcelTestDataProvider.class, dataProvider="ExcelDataProvider",priority=2)
	public void listOfSearchResultTest(String api) throws IOException, JSONException, AWTException
	{
		
		logger=report.startTest("Get certification list::List Of Search Result Test");
		LogerData.startTestCase("Get certification list::List Of Search Result Test");
		String token=loginCertification(UserName,Password);
		getlistOfSearchResult(api,token);
	}
	

}
