package com.certification.page.certificationSearch;

import java.awt.AWTException;
import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;

import com.certification.Utili.BrowserMethods;
import com.certification.Utili.LogerData;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class CertificationSearchDetailUtili extends BrowserMethods
{
	public void getCertificationSearch(String  searchUseingFilter,String api,String token,String ModuleIdSearch) throws IOException, JSONException, AWTException
	{
		
		client = new OkHttpClient();
		LogerData.info("URL Is::"+url+api+searchUseingFilter);
		request = new Request.Builder()
				.url(url+api+searchUseingFilter)
				.get()
				.addHeader("x-access-token", token)
				.addHeader("url",url)
				//.addHeader("cache-control", "no-cache")
				//.addHeader("postman-token", "340d3a6a-bf70-f59d-1a67-164c9612f866")
				.build();
		Response response = client.newCall(request).execute();
		int responseCode=response.code();
		LogerData.info("Searching response code is "+responseCode);
		Assert.assertEquals(200, responseCode);
		if(responseCode==200)
		{
			String jsonData = response.body().string();
			LogerData.info("-------------------jsonData-----------");
			LogerData.info(jsonData);
			JSONObject jsonObject = new JSONObject(jsonData);
			JSONObject chapitresJsonObject = jsonObject.getJSONObject("response");
			String numFound=chapitresJsonObject.getString("numFound");
			LogerData.info("numFound::::"+numFound);
			JSONArray chapitreJsonArray = chapitresJsonObject.getJSONArray("docs");

			for (int i = 0; i < chapitreJsonArray.length(); i++) 
			{
				JSONObject ChapJsonObject = chapitreJsonArray.getJSONObject(i);
				if(ModuleIdSearch.equalsIgnoreCase("MODULE_ID"))
				{
					String ActualModule_id = ChapJsonObject.getString("module_id");
					if(searchUseingFilter.equalsIgnoreCase(ActualModule_id))
					{
						Assert.assertEquals(searchUseingFilter, ActualModule_id);
						LogerData.pass("verify search with module is "+searchUseingFilter+"and actual Module ID is"+ActualModule_id);
						break;
					}else
					{
						LogerData.info("Excepted Module Id is not displaying");
					}
				}else if(ModuleIdSearch.equalsIgnoreCase("TITLE"))
				{
					String Actualtitle= ChapJsonObject.getString("title");
					if(searchUseingFilter.equalsIgnoreCase(Actualtitle))
					{
						Assert.assertEquals(searchUseingFilter, Actualtitle);
						LogerData.pass("verify search with module is "+searchUseingFilter+"and actual Module Title is "+Actualtitle);
						break;
					}else
					{
						LogerData.info("Excepted title is not displaying");
					}
				}
				else if(ModuleIdSearch.equalsIgnoreCase("DESCRIPTION"))
				{

					String Description= ChapJsonObject.getString("description");
					if(searchUseingFilter.equalsIgnoreCase(Description))
					{
						Assert.assertEquals(searchUseingFilter, Description);
						LogerData.pass("verify search with module is "+searchUseingFilter+"and actual Module Description"+Description);
						break;
					}else
					{
						LogerData.info("Excepted Description is not displaying");
					}
				
				}
			}

		}	
		else if(responseCode==400)
		{
			LogerData.fail("504 Bad Gateway");

		}else if(responseCode==504)
		{
			LogerData.fail("Not able to authenticate user::::504 Gateway TimeOut Error");
		}
	}
}
