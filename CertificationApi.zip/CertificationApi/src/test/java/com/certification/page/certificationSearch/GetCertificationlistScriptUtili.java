package com.certification.page.certificationSearch;

import java.awt.AWTException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certification.Utili.BrowserMethods;
import com.certification.Utili.CertificationCommon;
import com.certification.Utili.LogerData;
import com.certification.Utili.PropertyHandler;
import com.certification.excelReader.ExcelSheetHandel;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GetCertificationlistScriptUtili extends BrowserMethods  {
	CertificationCommon certificationCommon=new CertificationCommon();
	ExcelSheetHandel excelSheetHandel=new ExcelSheetHandel();		
	public void 	logIn(String UserName,String Password,String api) throws IOException, JSONException, AWTException, InvalidFormatException
	{
		LogerData.info("Log in User Name is"+UserName);
		LogerData.info("Log in Password is "+Password);
		String token=certificationCommon.loginCertification(UserName,Password);
		LogerData.info("token:::"+token);
		//excelSheetHandel.setExcelStringData(PropertyHandler.getProperty("TESTDATA"),"GetCertificationlistScript",6,2,token);
	}
	public void getlistOfSearchResult(String api,String token) throws IOException, JSONException, AWTException
	{
		LogerData.info("List of search result api is ::::::"+api);
		LogerData.info("List of search result token is ::::::"+token);
		client = new OkHttpClient();
		request = new Request.Builder()
				.url(url+api)
				.get()
				.addHeader("x-access-token", token)
				.addHeader("url", url)
				//.addHeader("cache-control", "no-cache")
				//.addHeader("postman-token", "d89dd73a-2a9b-be61-7609-17933eed0cc5")
				.build();
		Response response = client.newCall(request).execute();
		int responseCode=response.code();
		Assert.assertEquals(200, responseCode);
		if(responseCode==200)
		{
			String jsonData = response.body().string();
			LogerData.info("-------------------jsonData-----------");
			LogerData.info(jsonData);
			JSONObject jsonObject = new JSONObject(jsonData);
			JSONObject chapitresJsonObject = jsonObject.getJSONObject("response");
			String numFound=chapitresJsonObject.getString("numFound");
			LogerData.info("numFound::::"+numFound);
			JSONArray chapitreJsonArray = chapitresJsonObject.getJSONArray("docs");

			for (int i = 0; i < chapitreJsonArray.length(); i++) 
			{
				JSONObject ChapJsonObject = chapitreJsonArray.getJSONObject(i);
				String module_id = ChapJsonObject.getString("module_id");
				LogerData.info("module_id is::"+module_id);
				String Moduletitle = ChapJsonObject.getString("title");
				LogerData.info("ModuleTitle  is::"+Moduletitle);
				String ModuleDescription = ChapJsonObject.getString("description");
				LogerData.info("ModuleDescription  is::"+ModuleDescription);
			}

			LogerData.pass("Searching list api is working.");
		}	
		else if(responseCode==400)
		{
			LogerData.fail("504 Bad Gateway");

		}else if(responseCode==504)
		{
			LogerData.fail("Not able to authenticate user::::504 Gateway TimeOut Error");
		}
	}


}
